import React from 'react'
import Header from '../Component/Header'
import Sidebar from '../Component/Sidebar'

const Soon = () => {
  return (
    <div>
      {/* <Header/> */}
      {/* <Sidebar/> */}
      <div className='Comming-soon text-center mt-5'>
        <img src='https://img.freepik.com/free-vector/abstract-coming-soon-halftone-style-background-design_1017-27282.jpg' /> 
      </div>
    </div>
  )
}

export default Soon